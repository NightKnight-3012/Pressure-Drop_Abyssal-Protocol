# Pressure Drop — Step 1 patch

Contains only changed files. No new packages are required.

## Apply
1. Stop the server with Ctrl+C.
2. Back up your existing project folder.
3. Extract this ZIP.
4. Copy its `server` and `client` folders into the existing project folder and replace matching files.

Changed files:
- `server/index.js`
- `client/index.html`
- `client/src/main.js`
- `client/src/style.css`
- `client/src/network.js`
- `client/src/game.js`

Run from the project root:
```bat
npm run dev
```
Open http://localhost:5173.

Controls: WASD move, mouse look, Shift run/noise, hold E near a glowing panel for 5 seconds, F flashlight, Esc release mouse.

Prototype notes: the server owns flood, threat, repairs, impacts and win/lose state. The three repair targets are Control, Engineering and Pump. The pump reverses flooding. Win when all panels are repaired and all connected players reach Escape Pod Room. Lose when flood reaches the threshold. Water is currently a station-wide surface rather than independently simulated room volumes. Server validates movement speed and interior wall crossings; crate collision is client-side.
