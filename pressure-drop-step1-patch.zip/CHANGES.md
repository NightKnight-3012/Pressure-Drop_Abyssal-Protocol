# Step 1 — changed-file map

These are **full replacement files** for the listed paths. All other Step 0 files remain unchanged.

## `server/index.js` — replaced
- `game()` / `snapshot()` — authoritative shared match state: flood, threat, panels, progress, player count.
- `area()` / `wall()` — four-zone room classification and server-side interior-wall checks.
- `repair:start` / `repair:cancel` — validates target, player range, panel state, and repair ownership.
- server tick — raises flood, changes threat, finishes repairs after five server-timed seconds, applies pump effect, triggers hull impacts, and decides win/lose.
- `game:playAgain` — resets shared match state.

## `client/src/game.js` — replaced
- `layout()` — four differently colored floor zones, corridor openings, room labels, panels, and water plane.
- `move()` — Shift sprint, water movement penalty, and movement updates sent to the server.
- `hudUpdate()` — flood/threat meters, objective, room name, repair prompt/progress.
- `sound()` / `handleMonsterImpact()` — generated Web Audio cues, red flash, and screen shake.
- flashlight toggle, flickering lights, and shared win/lose overlay.

## `client/src/main.js` — replaced
- Binds the new shared state, repair completion, monster impact, reset, and match-over events to the game.

## `client/src/network.js` — replaced
- Adds movement's running flag, repair start/cancel, and Play Again events.

## `client/index.html` — replaced
- Adds the objective, flood/threat meters, interaction prompt, repair progress bar, room name, warning, and damage flash.

## `client/src/style.css` — replaced
- Styles the new HUD, meters, warning, repair progress, damage flash, and win/lose overlay.

## Known scope boundary
Water is a single shared station-wide plane; it is not yet separately simulated per room. Crate collision is client-side; the server validates movement speed, bounds, and the interior wall segments. No dependencies were added.
