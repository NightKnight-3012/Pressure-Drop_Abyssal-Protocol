import "./style.css";
import {socket,createRoom,joinRoom} from "./network.js";
import {startGame,handleGameState,handleMonsterImpact,handleRepairComplete,handleGameOver,handleGameReset} from "./game.js";
const $=id=>document.getElementById(id),name=$("player-name"),code=$("room-code"),create=$("create-room"),join=$("join-room"),status=$("menu-status");
const hud={lookPrompt:$("look-prompt"),countElement:$("player-count"),floodValue:$("flood-value"),floodFill:$("flood-fill"),threatValue:$("threat-value"),threatFill:$("threat-fill"),objective:$("objective"),interaction:$("interaction"),repairWrap:$("repair-wrap"),repairFill:$("repair-fill"),warning:$("warning"),damageFlash:$("damage-flash"),roomName:$("room-name"),crewCount:$("player-count")};
let entering=false;
function begin(fn){if(entering)return;if(!socket.connected){status.textContent="Connecting to server...";return}let n=name.value.trim().replace(/\s+/g," ");if(!n||n.length>16){status.textContent="Enter a name between 1 and 16 characters.";return}entering=true;create.disabled=join.disabled=true;status.textContent="ESTABLISHING COMMUNICATIONS...";fn(n)}
create.onclick=()=>begin(createRoom);
join.onclick=()=>{let c=code.value.trim().toUpperCase();if(!/^[A-Z0-9]{5}$/.test(c)){status.textContent="Enter a valid 5-character room code.";return}begin(n=>joinRoom(n,c))};
code.addEventListener("input",()=>code.value=code.value.toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,5));
socket.on("connect",()=>status.textContent="COMMUNICATIONS ONLINE. AWAITING CREW...");
socket.on("disconnect",()=>{status.textContent="CONNECTION LOST. RECONNECTING...";entering=false;create.disabled=join.disabled=false});
socket.on("connect_error",()=>status.textContent="SERVER UNAVAILABLE. CHECK THAT IT IS RUNNING.");
socket.on("game:error",m=>{entering=false;create.disabled=join.disabled=false;status.textContent=m});
socket.on("room:joined",d=>{if(!d?.state||!d.playerId)return; $("hud-room-code").textContent=d.roomCode;startGame(d.playerId,d.state,hud)});
socket.on("game:state",handleGameState);socket.on("monster:impact",handleMonsterImpact);socket.on("repair:complete",handleRepairComplete);socket.on("game:over",handleGameOver);socket.on("game:reset",handleGameReset);