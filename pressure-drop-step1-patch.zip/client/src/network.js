import { io } from "socket.io-client";
export const socket=io("http://localhost:3000",{autoConnect:true,reconnection:true});
export const createRoom=name=>socket.emit("room:create",{name});
export const joinRoom=(name,code)=>socket.emit("room:join",{name,code});
export const sendMovement=(x,z,rotation,running)=>socket.emit("player:move",{x,z,rotation,running});
export const startRepair=panelId=>socket.emit("repair:start",{panelId});
export const cancelRepair=panelId=>socket.emit("repair:cancel",{panelId});
export const playAgain=()=>socket.emit("game:playAgain");